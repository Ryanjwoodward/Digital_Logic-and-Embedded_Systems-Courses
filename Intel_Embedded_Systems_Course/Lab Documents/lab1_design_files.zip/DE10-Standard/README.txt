The file part2 is an ARM executable program. It is a sample solution to Part II. 
This sample solution exits after 12 seconds.

The file part3.ko is a kernel module. It is a sample solution using the HEX0 display 
for Part III.

The file part3_ASCII.ko is a kernel module. It is a sample solution using the 
Terminal window for Part III.
