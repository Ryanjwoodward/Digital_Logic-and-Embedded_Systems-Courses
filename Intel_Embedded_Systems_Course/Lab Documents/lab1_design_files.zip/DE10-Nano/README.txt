The file part2 is an ARM executable program. It is a sample solution to Part II. This sample
   solution exits after 12 seconds.

The file part3.ko is a kernel module. It is a sample solution to Part III.
